#!/usr/bin/env python
# coding: utf-8

# In[1]:


from ANIMALSHELTER import AnimalShelter
from bson.objectid import ObjectId


# In[2]:


USER ='aacuser'
PASS = 'pass1'
animals = AnimalShelter(USER, PASS)


# In[3]:


animal_data = {
    'rec_num': 1002,
    'age_upon_outcome': "6 Months",
    'animal_id': "A1002",
    'animal_type': "Cat",
    'breed': "short Hair",
    'color': "Black",
    'date_of_birth': "2024-01-12",
    'datetime':"",
    'monthyear': "2",
    'name': "CatDog",
    'outcome_subtype': "adoption",
    'sex_upon_outcome': "Male",
}

result = animals.create(animal_data)
print("insert successful", result)


# In[4]:


print(animals.create({0:0}))


# In[5]:


search_filter = {'name': 'CatDog'}
results = animals.read(search_filter)

if results:
    for animal in results:
        print(animal)
else:
    print("no matches")


# In[8]:


results = animals.read({})
for i, r in enumerate(results):
    if i >=20:
        break
    print(r)


# In[7]:


print(list(animals.read({0.0})))


# In[9]:


updateAnimal = animals.update({"name": "CatDog"}, {"outcome_type": "Adopted"})
print(updateAnimal)


# In[10]:


query = animals.read({"name": "CatDog"})
for animal in query:
    print(animal)


# In[11]:


deleteAnimal = animals.delete({"name": "CatDog"})
print(deleteAnimal)


# In[12]:


query = animals.read({"name": "CatDog"})
for animal in query:
    print(animal)


# In[ ]:




